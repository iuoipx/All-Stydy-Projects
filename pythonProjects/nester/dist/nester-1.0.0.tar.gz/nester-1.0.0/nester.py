#递归函数
def print_lol(_list):
    for item in _list:
        if isinstance(item,list):
            print_lol(item)  #如果所处理的列表项本身是一个列表，则调用函数
        else:
            print(item)