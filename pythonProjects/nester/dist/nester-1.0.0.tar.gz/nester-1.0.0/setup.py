from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='iuoip',
    author_email='466009198@qq.com',
    url='http://',
    description='A simple printer of nested lists'
)